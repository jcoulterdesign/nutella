# Vite + Tailwind 4.1 + Sass Starter

Commands:

- npm install
- npm run dev
- npm run build
- npm run preview
